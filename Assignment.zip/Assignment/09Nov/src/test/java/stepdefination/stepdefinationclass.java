package stepdefination;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdefinationclass {

WebDriver driver;
	
@Given("signup button is visible")
public void signup_button_is_visible() {

	System.setProperty("webdriver.chrome.driver", "C:\\Users\\0013K2744\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");
    driver = new ChromeDriver();
    driver.get("http://elearningm1.upskills.in");
    
}

@When("I click on signup button")
public void i_click_on_signup_button() {

driver.findElement(By.xpath("//a[contains(text(), 'Sign up!')]")).click();
}

@When("fill the required fields")
public void fill_the_required_fields() {
WebElement firstName = driver.findElement(By.xpath("//input[@name='firstname']"));
firstName.sendKeys("Pooja");
WebElement LastName = driver.findElement(By.xpath("//input[@name='lastname']"));
LastName.sendKeys("Mukundan");
WebElement email = driver.findElement(By.xpath("//input[@name='email']"));
email.sendKeys("mukundan.pooja@gmail.com");
WebElement username = driver.findElement(By.xpath("//input[@name='username']"));
username.sendKeys("Pooja3");
WebElement password = driver.findElement(By.xpath("//input[@name='pass1']"));
password.sendKeys("12345");
WebElement confirmPassword = driver.findElement(By.xpath("//input[@name='pass2']"));
confirmPassword.sendKeys("12345");

}

@When("click on register")
public void click_on_register() {
	driver.findElement(By.xpath("//button[@name = 'submit']")).click();

  
}

@Then("I validate that signup is successful")
public void i_validate_that_signup_is_successful() {
	driver.findElement(By.xpath("//button[@name = 'next']")).isDisplayed();

}



}
