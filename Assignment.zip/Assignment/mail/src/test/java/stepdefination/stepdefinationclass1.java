package stepdefination;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdefinationclass1 {

WebDriver driver;
	

@Given("Signup is succesful")
public void signup_is_succesful() {

System.setProperty("webdriver.chrome.driver", "C:\\Users\\0013K2744\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");
driver = new ChromeDriver();
    
    
}

@Given("website url is entered")
public void website_url_is_entered() {
driver.get("http://elearningm1.upskills.in");

}

@When("enter login details")
public void enter_login_details() {
	WebElement userName = driver.findElement(By.xpath("//input[@id='login']"));
	userName.sendKeys("Pooja1");
	WebElement password = driver.findElement(By.xpath("//input[@id='password']"));
	password.sendKeys("12345");
}

@When("click on login")
public void click_on_login() throws InterruptedException {
	driver.findElement(By.xpath("//button[@name = 'submitAuth']")).click();
Thread.sleep(3000);
}

@When("click on compose message")
public void click_on_compose_message() {
	driver.findElement(By.xpath("//image[@src = 'http://elearningm1.upskills.in/main/img/icons/22/new-message.png']")).click();
	
}

@When("enter send to details")
public void enter_send_to_details() {
	Select dropdown = new Select(driver.findElement(By.xpath("//input[@name='select2-search__field']")));  
	dropdown.selectByVisibleText("amit xyz");  
	  

}

@When("enter subject")
public void enter_subject() {

	WebElement subject = driver.findElement(By.xpath("//input[@name='title']"));
	subject.sendKeys("Hi");
}

@When("click on send message")
public void click_on_send_message() {
	driver.findElement(By.xpath("//button[@class = 'btn btn-primary']")).click();

}

@Then("I validate the mesage is sent")
public void i_validate_the_mesage_is_sent() {


}



}
